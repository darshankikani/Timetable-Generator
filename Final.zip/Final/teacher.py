import sqlite3
conn = sqlite3.connect('teacher.db')
c=conn.cursor()
def create_table():

    c.execute("CREATE TABLE IF NOT EXISTS trial4(Teacherid TEXT,Teachername TEXT,Teacheradd TEXT,Teachermobileno REAL,Teacheremailid TEXT)")

    conn.commit()
    c.close()
    conn.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()
create_table()    
