# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'labinformation.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from lab import Ui_lab11
import sqlite3

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_labss(object):

    def setupUi(self, labss):
        labss.setObjectName(_fromUtf8("labss"))
        labss.resize(708, 296)
        self.labinformation = QtGui.QLabel(labss)
        self.labinformation.setGeometry(QtCore.QRect(280, 40, 131, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.labinformation.setFont(font)
        self.labinformation.setObjectName(_fromUtf8("labinformation"))
        self.nooflabs_label = QtGui.QLabel(labss)
        self.nooflabs_label.setGeometry(QtCore.QRect(130, 100, 81, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.nooflabs_label.setFont(font)
        self.nooflabs_label.setObjectName(_fromUtf8("nooflabs_label"))
        self.comboBox_nooflabs = QtGui.QComboBox(labss)
        self.comboBox_nooflabs.setGeometry(QtCore.QRect(260, 100, 121, 22))
        self.comboBox_nooflabs.setObjectName(_fromUtf8("comboBox_nooflabs"))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.comboBox_nooflabs.setItemText(0, _fromUtf8(""))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.comboBox_nooflabs.addItem(_fromUtf8(""))
        self.pushButton_nooflabs = QtGui.QPushButton(labss)
        self.pushButton_nooflabs.setGeometry(QtCore.QRect(280, 160, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_nooflabs.setFont(font)
        self.pushButton_nooflabs.setObjectName(_fromUtf8("pushButton_nooflabs"))
##########################33
        self.pushButton_nooflabs.clicked.connect(self.info6)
        ####################
        self.retranslateUi(labss)
        QtCore.QMetaObject.connectSlotsByName(labss)

    def retranslateUi(self, labss):
        labss.setWindowTitle(_translate("labss", "WizardPage", None))
        self.labinformation.setText(_translate("labss", "Lab information", None))
        self.nooflabs_label.setText(_translate("labss", "No of Labs", None))
        self.comboBox_nooflabs.setItemText(1, _translate("labss", "1", None))
        self.comboBox_nooflabs.setItemText(2, _translate("labss", "2", None))
        self.comboBox_nooflabs.setItemText(3, _translate("labss", "3", None))
        self.comboBox_nooflabs.setItemText(4, _translate("labss", "4", None))
        self.comboBox_nooflabs.setItemText(5, _translate("labss", "5", None))
        self.pushButton_nooflabs.setText(_translate("labss", "submit", None))


    def info6(self):
        self.lab11 = QtGui.QWizardPage()
        self.ui = Ui_lab11()
        self.ui.setupUi(self.lab11)
        self.lab11.show()

    
if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    labss = QtGui.QWizardPage()
    ui = Ui_labss()
    ui.setupUi(labss)
    labss.show()
    sys.exit(app.exec_())

