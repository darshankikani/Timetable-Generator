import sqlite3
db=sqlite3.connect('lab.db')
cursor=db.cursor()
col = cursor.execute('''SELECT LabName FROM lab1''').fetchall()
a=col[0][0]
b=col[1][0]
c=col[2][0]
d=col[3][0]
e=col[4][0]
print(a,b,c,d,e)
#allrows=cursor.fetchall()
##for row in allrows:
##   print(row[0],row[1],row[2],row[3],row[4])
##        a=row[0]
##        b=row[1]
##        c=row[2]
##        d=row[3]
##        e=row[4]
##        f=row[5]
##     
##        connection  = sqlite3.connect("userResDet.db")
##        connection.execute("INSERT INTO reservationDetails (UniqueID,TravelDate,QUOTA,TotalSeats,TotalFare,User_Name,Booked) VALUES(?,?,?,?,?,?,?) ",(usrname,a,b,c,d,e,f,))
##       
        ##connection.commit()
##        connection.close()
