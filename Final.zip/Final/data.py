import sqlite3
conn = sqlite3.connect('data.db')
c=conn.cursor()
def create_table():

    c.execute("CREATE TABLE IF NOT EXISTS trial1(Coursename TEXT,Noofsubject TEXT,Teacherid TEXT,Teachername TEXT,teacherAddress TEXT,Teachermobileno Text,Emailid TEXT,Classroom TEXT,RCourse1 TEXT,RCourse2 TEXT,RCourse3 TEXT,RCourse4 TEXT,RCourse5 TEXT,Nooflecture TEXT)")

    conn.commit()
    c.close()
    conn.close()
##def read():
##    c.execute("SELECT * FROM USERINFO")
##    for row in c.fetchall():
##        print(row)






##read()

create_table()    
