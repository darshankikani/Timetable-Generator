# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'timetable.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ce1(object):
    
    def setupUi(self, ce1):
        ce1.setObjectName(_fromUtf8("ce1"))
        ce1.resize(671, 331)
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.label = QtGui.QLabel(self.tab)
        self.label.setGeometry(QtCore.QRect(30, 30, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.label_3 = QtGui.QLabel(self.tab)
        self.label_3.setGeometry(QtCore.QRect(140, 30, 41, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_4 = QtGui.QLabel(self.tab)
        self.label_4.setGeometry(QtCore.QRect(540, 30, 41, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_5 = QtGui.QLabel(self.tab)
        self.label_5.setGeometry(QtCore.QRect(450, 30, 41, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_5.setFont(font)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.label_6 = QtGui.QLabel(self.tab)
        self.label_6.setGeometry(QtCore.QRect(360, 30, 41, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_6.setFont(font)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.label_7 = QtGui.QLabel(self.tab)
        self.label_7.setGeometry(QtCore.QRect(250, 30, 41, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_7.setFont(font)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.m11 = QtGui.QLineEdit(self.tab)
        
        self.m11.setGeometry(QtCore.QRect(10, 60, 101, 20))
        self.m11.setObjectName(_fromUtf8("m11"))
        self.t11 = QtGui.QLineEdit(self.tab)
        self.t11.setGeometry(QtCore.QRect(110, 60, 101, 20))
        self.t11.setObjectName(_fromUtf8("t11"))
        self.w11 = QtGui.QLineEdit(self.tab)
        self.w11.setGeometry(QtCore.QRect(210, 60, 101, 20))
        self.w11.setObjectName(_fromUtf8("w11"))
        self.th11 = QtGui.QLineEdit(self.tab)
        self.th11.setGeometry(QtCore.QRect(310, 60, 101, 20))
        self.th11.setObjectName(_fromUtf8("th11"))
        self.f11 = QtGui.QLineEdit(self.tab)
        self.f11.setGeometry(QtCore.QRect(410, 60, 101, 20))
        self.f11.setObjectName(_fromUtf8("f11"))
        ####
        db=sqlite3.connect('lab.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT LabName FROM lab1''').fetchall()
        a=col[0][0]
        b=col[1][0]
        c=col[2][0]
        d=col[3][0]
        e=col[4][0]
        
        self.m11.setText(a)
        self.t11.setText(b)
        self.w11.setText(c)
        self.th11.setText(d)
        self.f11.setText(e)

      
        ####
        self.s11 = QtGui.QLineEdit(self.tab)
        self.s11.setGeometry(QtCore.QRect(510, 60, 101, 20))
        self.s11.setObjectName(_fromUtf8("s11"))
####
        db=sqlite3.connect('Subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a111=col[6][0]

        self.s11.setText(a111)

      
        ####
        self.m12 = QtGui.QLineEdit(self.tab)
        self.m12.setGeometry(QtCore.QRect(10, 110, 101, 20))
        self.m12.setObjectName(_fromUtf8("m12"))
        self.t12 = QtGui.QLineEdit(self.tab)
        self.t12.setGeometry(QtCore.QRect(110, 110, 101, 20))
        self.t12.setObjectName(_fromUtf8("t12"))
        self.w12 = QtGui.QLineEdit(self.tab)
        self.w12.setGeometry(QtCore.QRect(210, 110, 101, 20))
        self.w12.setObjectName(_fromUtf8("w12"))
        self.th12 = QtGui.QLineEdit(self.tab)
        self.th12.setGeometry(QtCore.QRect(310, 110, 101, 20))
        self.th12.setObjectName(_fromUtf8("th12"))
        self.f12 = QtGui.QLineEdit(self.tab)
        self.f12.setGeometry(QtCore.QRect(410, 110, 101, 20))
        self.f12.setObjectName(_fromUtf8("f12"))
        self.s12 = QtGui.QLineEdit(self.tab)
        self.s12.setGeometry(QtCore.QRect(510, 110, 101, 20))
        self.s12.setObjectName(_fromUtf8("s12"))
        ########################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m12.setText(f1)
        self.t12.setText(d1)
        self.w12.setText(c1)
        self.th12.setText(f1)
        self.f12.setText(b1)
        self.s12.setText(g1)
    
        #########################
        self.m13 = QtGui.QLineEdit(self.tab)
        self.m13.setGeometry(QtCore.QRect(10, 130, 101, 20))
        self.m13.setObjectName(_fromUtf8("m13"))
        self.t13 = QtGui.QLineEdit(self.tab)
        self.t13.setGeometry(QtCore.QRect(110, 130, 101, 20))
        self.t13.setObjectName(_fromUtf8("t13"))
        self.w13 = QtGui.QLineEdit(self.tab)
        self.w13.setGeometry(QtCore.QRect(210, 130, 101, 20))
        self.w13.setObjectName(_fromUtf8("w13"))
        self.lineEdit_16 = QtGui.QLineEdit(self.tab)
        self.lineEdit_16.setGeometry(QtCore.QRect(310, 130, 101, 20))
        self.lineEdit_16.setObjectName(_fromUtf8("lineEdit_16"))
        self.f13 = QtGui.QLineEdit(self.tab)
        self.f13.setGeometry(QtCore.QRect(410, 130, 101, 20))
        self.f13.setObjectName(_fromUtf8("f13"))
        self.s13 = QtGui.QLineEdit(self.tab)
        self.s13.setGeometry(QtCore.QRect(510, 130, 101, 20))
        self.s13.setObjectName(_fromUtf8("s13"))
        #############
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m13.setText(e1)
        self.t13.setText(a1)
        self.w13.setText(a1)
        self.lineEdit_16.setText(c1)
        self.f13.setText(d1)
        self.s13.setText(g1)

        ##############
        self.m14 = QtGui.QLineEdit(self.tab)
        self.m14.setGeometry(QtCore.QRect(10, 180, 101, 20))
        self.m14.setObjectName(_fromUtf8("m14"))
        self.t14 = QtGui.QLineEdit(self.tab)
        self.t14.setGeometry(QtCore.QRect(110, 180, 101, 20))
        self.t14.setObjectName(_fromUtf8("t14"))
        self.w14 = QtGui.QLineEdit(self.tab)
        self.w14.setGeometry(QtCore.QRect(210, 180, 101, 20))
        self.w14.setObjectName(_fromUtf8("w14"))
        self.th13 = QtGui.QLineEdit(self.tab)
        self.th13.setGeometry(QtCore.QRect(310, 180, 101, 20))
        self.th13.setObjectName(_fromUtf8("th13"))
        self.f14 = QtGui.QLineEdit(self.tab)
        self.f14.setGeometry(QtCore.QRect(410, 180, 101, 20))
        self.f14.setObjectName(_fromUtf8("f14"))
        self.s14 = QtGui.QLineEdit(self.tab)
        self.s14.setGeometry(QtCore.QRect(510, 180, 101, 20))
        self.s14.setObjectName(_fromUtf8("s14"))
        #################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m14.setText(c1)
        self.t14.setText(e1)
        self.w14.setText(b1)
        self.th13.setText(e1)
        

        ################
        self.m15 = QtGui.QLineEdit(self.tab)
        self.m15.setGeometry(QtCore.QRect(10, 200, 101, 20))
        self.m15.setObjectName(_fromUtf8("m15"))
        self.t15 = QtGui.QLineEdit(self.tab)
        self.t15.setGeometry(QtCore.QRect(110, 200, 101, 20))
        self.t15.setObjectName(_fromUtf8("t15"))
        self.w15 = QtGui.QLineEdit(self.tab)
        self.w15.setGeometry(QtCore.QRect(210, 200, 101, 20))
        self.w15.setObjectName(_fromUtf8("w15"))
        self.th15 = QtGui.QLineEdit(self.tab)
        self.th15.setGeometry(QtCore.QRect(310, 200, 101, 20))
        self.th15.setObjectName(_fromUtf8("th15"))
        self.f15 = QtGui.QLineEdit(self.tab)
        self.f15.setGeometry(QtCore.QRect(410, 200, 101, 20))
        self.f15.setObjectName(_fromUtf8("f15"))
        self.s15 = QtGui.QLineEdit(self.tab)
        self.s15.setGeometry(QtCore.QRect(510, 200, 101, 20))
        self.s15.setObjectName(_fromUtf8("s15"))
        ######################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m15.setText(b1)
        self.t15.setText(f1)
        self.w15.setText(d1)
        self.th15.setText(a1)


        ######################
        ce1.addTab(self.tab, _fromUtf8(""))
        self.tab1 = QtGui.QWidget()
        self.tab1.setObjectName(_fromUtf8("tab1"))
        self.label_2 = QtGui.QLabel(self.tab1)
        self.label_2.setGeometry(QtCore.QRect(20, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_8 = QtGui.QLabel(self.tab1)
        self.label_8.setGeometry(QtCore.QRect(130, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_8.setFont(font)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.label_9 = QtGui.QLabel(self.tab1)
        self.label_9.setGeometry(QtCore.QRect(250, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_9.setFont(font)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.label_10 = QtGui.QLabel(self.tab1)
        self.label_10.setGeometry(QtCore.QRect(350, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_10.setFont(font)
        self.label_10.setObjectName(_fromUtf8("label_10"))
        self.label_11 = QtGui.QLabel(self.tab1)
        self.label_11.setGeometry(QtCore.QRect(440, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_11.setFont(font)
        self.label_11.setObjectName(_fromUtf8("label_11"))
        self.label_12 = QtGui.QLabel(self.tab1)
        self.label_12.setGeometry(QtCore.QRect(530, 40, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_12.setFont(font)
        self.label_12.setObjectName(_fromUtf8("label_12"))
        self.m21 = QtGui.QLineEdit(self.tab1)
        self.m21.setGeometry(QtCore.QRect(10, 70, 101, 20))
        self.m21.setObjectName(_fromUtf8("m21"))
        self.t21 = QtGui.QLineEdit(self.tab1)
        self.t21.setGeometry(QtCore.QRect(110, 70, 101, 20))
        self.t21.setObjectName(_fromUtf8("t21"))
        self.w21 = QtGui.QLineEdit(self.tab1)
        self.w21.setGeometry(QtCore.QRect(210, 70, 101, 20))
        self.w21.setObjectName(_fromUtf8("w21"))
        self.th21 = QtGui.QLineEdit(self.tab1)
        self.th21.setGeometry(QtCore.QRect(310, 70, 101, 20))
        self.th21.setObjectName(_fromUtf8("th21"))
        self.f21 = QtGui.QLineEdit(self.tab1)
        self.f21.setGeometry(QtCore.QRect(410, 70, 101, 20))
        self.f21.setObjectName(_fromUtf8("f21"))
        ###########################
        db=sqlite3.connect('lab.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT LabName FROM lab1''').fetchall()
        a=col[0][0]
        b=col[1][0]
        c=col[2][0]
        d=col[3][0]
        e=col[4][0]

        self.m21.setText(b)
        self.t21.setText(c)
        self.w21.setText(d)
        self.th21.setText(e)
        self.f21.setText(a)

     ##############3 
        self.s21 = QtGui.QLineEdit(self.tab1)
        self.s21.setGeometry(QtCore.QRect(510, 70, 101, 20))
        self.s21.setObjectName(_fromUtf8("s21"))
        #################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a222=col[6][0]
  
        self.s21.setText(a222)
  
     ##############3 
        self.m22 = QtGui.QLineEdit(self.tab1)
        self.m22.setGeometry(QtCore.QRect(10, 120, 101, 20))
        self.m22.setObjectName(_fromUtf8("m22"))
        self.t22 = QtGui.QLineEdit(self.tab1)
        self.t22.setGeometry(QtCore.QRect(110, 120, 101, 20))
        self.t22.setObjectName(_fromUtf8("t22"))
        self.w22 = QtGui.QLineEdit(self.tab1)
        self.w22.setGeometry(QtCore.QRect(210, 120, 101, 20))
        self.w22.setObjectName(_fromUtf8("w22"))
        self.th22 = QtGui.QLineEdit(self.tab1)
        self.th22.setGeometry(QtCore.QRect(310, 120, 101, 20))
        self.th22.setObjectName(_fromUtf8("th22"))
        self.f22 = QtGui.QLineEdit(self.tab1)
        self.f22.setGeometry(QtCore.QRect(410, 120, 101, 20))
        self.f22.setObjectName(_fromUtf8("f22"))
        self.s22 = QtGui.QLineEdit(self.tab1)
        self.s22.setGeometry(QtCore.QRect(510, 120, 101, 20))
        self.s22.setObjectName(_fromUtf8("s22"))
        #################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m22.setText(d1)
        self.t22.setText(f1)
        self.w22.setText(f1)
        self.th22.setText(c1)
        self.f22.setText(d1)
        self.s22.setText(g1)

        ###################
        self.m23 = QtGui.QLineEdit(self.tab1)
        self.m23.setGeometry(QtCore.QRect(10, 140, 101, 20))
        self.m23.setObjectName(_fromUtf8("m23"))
        self.t23 = QtGui.QLineEdit(self.tab1)
        self.t23.setGeometry(QtCore.QRect(110, 140, 101, 20))
        self.t23.setObjectName(_fromUtf8("t23"))
        self.w23 = QtGui.QLineEdit(self.tab1)
        self.w23.setGeometry(QtCore.QRect(210, 140, 101, 20))
        self.w23.setObjectName(_fromUtf8("w23"))
        self.th23 = QtGui.QLineEdit(self.tab1)
        self.th23.setGeometry(QtCore.QRect(310, 140, 101, 20))
        self.th23.setObjectName(_fromUtf8("th23"))
        self.f23 = QtGui.QLineEdit(self.tab1)
        self.f23.setGeometry(QtCore.QRect(410, 140, 101, 20))
        self.f23.setObjectName(_fromUtf8("f23"))
        self.s23 = QtGui.QLineEdit(self.tab1)
        self.s23.setGeometry(QtCore.QRect(510, 140, 101, 20))
        self.s23.setObjectName(_fromUtf8("s23"))
        ##########
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m23.setText(a1)
        self.t23.setText(c1)
        self.w23.setText(e1)
        self.th23.setText(a1)
        self.f23.setText(b1)
        self.s23.setText(g1)

        ########
        self.w24 = QtGui.QLineEdit(self.tab1)
        self.w24.setGeometry(QtCore.QRect(210, 180, 101, 20))
        self.w24.setObjectName(_fromUtf8("w24"))
        self.t24 = QtGui.QLineEdit(self.tab1)
        self.t24.setGeometry(QtCore.QRect(110, 180, 101, 20))
        self.t24.setObjectName(_fromUtf8("t24"))
        self.m24 = QtGui.QLineEdit(self.tab1)
        self.m24.setGeometry(QtCore.QRect(10, 180, 101, 20))
        self.m24.setObjectName(_fromUtf8("m24"))
        self.m25 = QtGui.QLineEdit(self.tab1)
        self.m25.setGeometry(QtCore.QRect(10, 200, 101, 20))
        self.m25.setObjectName(_fromUtf8("m25"))
        ##############################3
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[5][0]
        
        self.m25.setText(a1)
        
        #############################
        self.s24 = QtGui.QLineEdit(self.tab1)
        self.s24.setGeometry(QtCore.QRect(510, 180, 101, 20))
        self.s24.setObjectName(_fromUtf8("s24"))
        ###########
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m24.setText(e1)
        self.t24.setText(a1)
        self.w24.setText(c1)
        
        ###############
        self.f24 = QtGui.QLineEdit(self.tab1)
        self.f24.setGeometry(QtCore.QRect(410, 180, 101, 20))
        self.f24.setObjectName(_fromUtf8("f24"))
        ######
        
        ######
        self.th24 = QtGui.QLineEdit(self.tab1)
        self.th24.setGeometry(QtCore.QRect(310, 180, 101, 20))
        self.th24.setObjectName(_fromUtf8("th24"))
        ################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[1][0]
        
        self.th24.setText(a1)

        ################
        self.t25 = QtGui.QLineEdit(self.tab1)
        self.t25.setGeometry(QtCore.QRect(110, 200, 101, 20))
        self.t25.setObjectName(_fromUtf8("t25"))
        self.w25 = QtGui.QLineEdit(self.tab1)
        self.w25.setGeometry(QtCore.QRect(210, 200, 101, 20))
        self.w25.setObjectName(_fromUtf8("w25"))
        self.th25 = QtGui.QLineEdit(self.tab1)
        self.th25.setGeometry(QtCore.QRect(310, 200, 101, 20))
        self.th25.setObjectName(_fromUtf8("th25"))
        self.s25 = QtGui.QLineEdit(self.tab1)
        self.s25.setGeometry(QtCore.QRect(510, 200, 101, 20))
        self.s25.setObjectName(_fromUtf8("s25"))
        self.f25 = QtGui.QLineEdit(self.tab1)
        self.f25.setGeometry(QtCore.QRect(410, 200, 101, 20))
        self.f25.setObjectName(_fromUtf8("f25"))
        ce1.addTab(self.tab1, _fromUtf8(""))
######################
        db=sqlite3.connect('subject.db')
        cursor=db.cursor()
        col = cursor.execute('''SELECT Subjectname FROM trial3''').fetchall()
        a1=col[0][0]
        b1=col[1][0]
        c1=col[2][0]
        d1=col[3][0]
        e1=col[4][0]
        f1=col[5][0]
        g1=col[6][0]
        
        self.m25.setText(f1)
        self.t25.setText(e1)
        self.w25.setText(b1)
        self.th25.setText(d1)


        ###################
        self.retranslateUi(ce1)
        ce1.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(ce1)

    def retranslateUi(self, ce1):
        ce1.setWindowTitle(_translate("ce1", "TabWidget", None))
        self.label.setText(_translate("ce1", "MON", None))
        self.label_3.setText(_translate("ce1", "TUE", None))
        self.label_4.setText(_translate("ce1", "SAT", None))
        self.label_5.setText(_translate("ce1", "FRI", None))
        self.label_6.setText(_translate("ce1", "THU", None))
        self.label_7.setText(_translate("ce1", "WED", None))
        ce1.setTabText(ce1.indexOf(self.tab), _translate("ce1", "CE-1", None))
        self.label_2.setText(_translate("ce1", "MON", None))
        self.label_8.setText(_translate("ce1", "TUE", None))
        self.label_9.setText(_translate("ce1", "WED", None))
        self.label_10.setText(_translate("ce1", "THU", None))
        self.label_11.setText(_translate("ce1", "FRI", None))
        self.label_12.setText(_translate("ce1", "SAT", None))
        ce1.setTabText(ce1.indexOf(self.tab1), _translate("ce1", "CE-2", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    ce1 = QtGui.QTabWidget()
    ui = Ui_ce1()
    ui.setupUi(ce1)
    ce1.show()
    sys.exit(app.exec_())

