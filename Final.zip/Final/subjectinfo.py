# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'subjectinfo.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_subjectinfo1(object):
    def insertData1(self):
            sname = self.subjectname_lineEdit.text()
            code=self.code_lineEdit.text()
            
            connection  = sqlite3.connect("subject.db")
            connection.execute("INSERT INTO trial3 VALUES(?,?)",(sname,code))
            connection.commit()
            connection.close()

    def setupUi(self, subjectinfo1):
        subjectinfo1.setObjectName(_fromUtf8("subjectinfo1"))
        subjectinfo1.resize(705, 389)
        font = QtGui.QFont()
        font.setPointSize(12)
        subjectinfo1.setFont(font)
        self.label = QtGui.QLabel(subjectinfo1)
        self.label.setGeometry(QtCore.QRect(290, 20, 101, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.subjectname = QtGui.QLabel(subjectinfo1)
        self.subjectname.setGeometry(QtCore.QRect(60, 110, 111, 16))
        self.subjectname.setObjectName(_fromUtf8("subjectname"))
        self.subjectname_lineEdit = QtGui.QLineEdit(subjectinfo1)
        self.subjectname_lineEdit.setGeometry(QtCore.QRect(200, 110, 171, 20))
        self.subjectname_lineEdit.setObjectName(_fromUtf8("subjectname_lineEdit"))
        self.code = QtGui.QLabel(subjectinfo1)
        self.code.setGeometry(QtCore.QRect(60, 150, 111, 16))
        self.code.setObjectName(_fromUtf8("code"))
        self.code_lineEdit = QtGui.QLineEdit(subjectinfo1)
        self.code_lineEdit.setGeometry(QtCore.QRect(200, 150, 171, 20))
        self.code_lineEdit.setObjectName(_fromUtf8("code_lineEdit"))
        self.subjectinfo = QtGui.QPushButton(subjectinfo1)
        self.subjectinfo.setGeometry(QtCore.QRect(230, 220, 75, 23))
        self.subjectinfo.setObjectName(_fromUtf8("subjectinfo"))
#####################3
        self.subjectinfo.clicked.connect(self.insertData1)
        #####################
        self.retranslateUi(subjectinfo1)
        QtCore.QMetaObject.connectSlotsByName(subjectinfo1)

    def retranslateUi(self, subjectinfo1):
        subjectinfo1.setWindowTitle(_translate("subjectinfo1", "WizardPage", None))
        self.label.setText(_translate("subjectinfo1", "Subject Info", None))
        self.subjectname.setText(_translate("subjectinfo1", "Subject Name :", None))
        self.code.setText(_translate("subjectinfo1", "Subject Code :", None))
        self.subjectinfo.setText(_translate("subjectinfo1", "Submit", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    subjectinfo1 = QtGui.QWizardPage()
    ui = Ui_subjectinfo1()
    ui.setupUi(subjectinfo1)
    subjectinfo1.show()
    sys.exit(app.exec_())

