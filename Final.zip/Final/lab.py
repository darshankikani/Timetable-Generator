# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'lab.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sqlite3

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_lab11(object):
    #########################
    def insertData5(self):
            lname = self.lineEdit.text()
            lroomno=self.comboBox.currentText()
            connection  = sqlite3.connect("lab.db")
            connection.execute("INSERT INTO lab1 VALUES(?,?)",(llname,lroomno))
            connection.commit()
            connection.close()

    #########################
    def setupUi(self, lab11):
        lab11.setObjectName(_fromUtf8("lab11"))
        lab11.resize(638, 303)
        self.nameoflab = QtGui.QLabel(lab11)
        self.nameoflab.setGeometry(QtCore.QRect(140, 60, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.nameoflab.setFont(font)
        self.nameoflab.setObjectName(_fromUtf8("nameoflab"))
        self.lineEdit = QtGui.QLineEdit(lab11)
        self.lineEdit.setGeometry(QtCore.QRect(240, 60, 151, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.labroomno = QtGui.QLabel(lab11)
        self.labroomno.setGeometry(QtCore.QRect(140, 100, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.labroomno.setFont(font)
        self.labroomno.setObjectName(_fromUtf8("labroomno"))
        self.comboBox = QtGui.QComboBox(lab11)
        self.comboBox.setGeometry(QtCore.QRect(240, 100, 101, 22))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.setItemText(0, _fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.submitlabname = QtGui.QPushButton(lab11)
        self.submitlabname.setGeometry(QtCore.QRect(240, 180, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.submitlabname.setFont(font)
        self.submitlabname.setObjectName(_fromUtf8("submitlabname"))
        ###################################
        self.submitlabname.clicked.connect(self.insertData5)
        ###################################

        self.retranslateUi(lab11)
        QtCore.QMetaObject.connectSlotsByName(lab11)

    def retranslateUi(self, lab11):
        lab11.setWindowTitle(_translate("lab11", "WizardPage", None))
        self.nameoflab.setText(_translate("lab11", "Lab Name", None))
        self.labroomno.setText(_translate("lab11", "Room No", None))
        self.comboBox.setItemText(1, _translate("lab11", "1", None))
        self.comboBox.setItemText(2, _translate("lab11", "2", None))
        self.comboBox.setItemText(3, _translate("lab11", "3", None))
        self.comboBox.setItemText(4, _translate("lab11", "4", None))
        self.comboBox.setItemText(5, _translate("lab11", "5", None))
        self.submitlabname.setText(_translate("lab11", "Submit", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    lab11 = QtGui.QWizardPage()
    ui = Ui_lab11()
    ui.setupUi(lab11)
    lab11.show()
    sys.exit(app.exec_())

